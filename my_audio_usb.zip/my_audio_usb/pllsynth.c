/* PLL synteza SAA1057, LCD display */

#include "stm32f4xx_spi.h"
#include "stm32f4xx_rcc.h"
#include "main.h"

#define PLL_SPI SPI2
#define PLL_SPI_CLK RCC_APB1Periph_SPI2
#define PLL_SPI_SCK_GPIO_CLK RCC_AHB1Periph_GPIOB
#define PLL_SPI_MOSI_GPIO_CLK RCC_AHB1Periph_GPIOB
#define PLL_SPI_CS_GPIO_CLK RCC_AHB1Periph_GPIOC

#define PLL_SPI_MOSI_SOURCE GPIO_PinSource15
#define PLL_SPI_MOSI_PIN GPIO_Pin_15

#define PLL_SPI_SCK_SOURCE GPIO_PinSource10
#define PLL_SPI_SCK_PIN GPIO_Pin_10

#define PLL_SPI_CS_PIN GPIO_Pin_2
#define PLL_SPI_SCK_AF GPIO_AF_SPI2
#define PLL_SPI_MOSI_AF GPIO_AF_SPI2
#define PLL_SPI_CS_GPIO_PORT GPIOC
#define PLL_SPI_MOSI_GPIO_PORT GPIOB
#define PLL_SPI_SCK_GPIO_PORT GPIOB

void InitPLLPorts(void)
{
	 GPIO_InitTypeDef GPIO_InitStructure;

	 /* Enable SCK, MOSI and MISO GPIO clocks */
		  RCC_AHB1PeriphClockCmd(PLL_SPI_SCK_GPIO_CLK | PLL_SPI_MOSI_GPIO_CLK, ENABLE);

		  /* Enable CS  GPIO clock */
		  RCC_AHB1PeriphClockCmd(PLL_SPI_CS_GPIO_CLK, ENABLE);

		  /* Enable INT1 GPIO clock */
		  //RCC_AHB1PeriphClockCmd(LIS302DL_SPI_INT1_GPIO_CLK, ENABLE);

		  /* Enable INT2 GPIO clock */
		  //RCC_AHB1PeriphClockCmd(LIS302DL_SPI_INT2_GPIO_CLK, ENABLE);

		  GPIO_PinAFConfig(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_SOURCE, PLL_SPI_SCK_AF);
		  //GPIO_PinAFConfig(LIS302DL_SPI_MISO_GPIO_PORT, LIS302DL_SPI_MISO_SOURCE, LIS302DL_SPI_MISO_AF);
		  GPIO_PinAFConfig(PLL_SPI_MOSI_GPIO_PORT, PLL_SPI_MOSI_SOURCE, PLL_SPI_MOSI_AF);

		  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
		  //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
		  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_DOWN;
		  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

		  /* SPI SCK pin configuration */
		  GPIO_InitStructure.GPIO_Pin = PLL_SPI_SCK_PIN;
		  GPIO_Init(PLL_SPI_SCK_GPIO_PORT, &GPIO_InitStructure);

		  /* SPI  MOSI pin configuration */
		  GPIO_InitStructure.GPIO_Pin = PLL_SPI_MOSI_PIN;
		  GPIO_Init(PLL_SPI_MOSI_GPIO_PORT, &GPIO_InitStructure);

		  /* SPI MISO pin configuration */
		  //GPIO_InitStructure.GPIO_Pin = LIS302DL_SPI_MISO_PIN;
		  //GPIO_Init(LIS302DL_SPI_MISO_GPIO_PORT, &GPIO_InitStructure);

		  /* Configure GPIO PIN for PLL Chip select */
		  GPIO_InitStructure.GPIO_Pin = PLL_SPI_CS_PIN;
		  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
		  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		  GPIO_Init(PLL_SPI_CS_GPIO_PORT, &GPIO_InitStructure);

		  /* Deselect : Chip Select low */

		  GPIO_ResetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN);

		  /* Configure GPIO PINs to detect Interrupts */
		 /* GPIO_InitStructure.GPIO_Pin = LIS302DL_SPI_INT1_PIN;
		  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
		  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
		  GPIO_Init(LIS302DL_SPI_INT1_GPIO_PORT, &GPIO_InitStructure);

		  GPIO_InitStructure.GPIO_Pin = LIS302DL_SPI_INT2_PIN;
		  GPIO_Init(LIS302DL_SPI_INT2_GPIO_PORT, &GPIO_InitStructure);*/

}

void InitPLLSPI(void)
{
    SPI_InitTypeDef PLL_SPI_InitStruct;
    /* Enable the SPI periph clock*/
	RCC_APB1PeriphClockCmd(PLL_SPI_CLK, ENABLE);
	/*Init PLL SPI */
	SPI_I2S_DeInit(PLL_SPI);
	PLL_SPI_InitStruct.SPI_Direction=SPI_Direction_1Line_Tx;
	PLL_SPI_InitStruct.SPI_Mode=SPI_Mode_Master;
	PLL_SPI_InitStruct.SPI_DataSize=SPI_DataSize_8b;
	PLL_SPI_InitStruct.SPI_CPOL=SPI_CPOL_Low;
	PLL_SPI_InitStruct.SPI_CPHA=SPI_CPHA_1Edge;
	PLL_SPI_InitStruct.SPI_NSS=SPI_NSS_Soft;
	PLL_SPI_InitStruct.SPI_FirstBit=SPI_FirstBit_LSB;
	PLL_SPI_InitStruct.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_256;
	SPI_Init(PLL_SPI, &PLL_SPI_InitStruct);
	SPI_Cmd(PLL_SPI,ENABLE);
}

void PLLSoftSPI(uint16_t code)
{uint16_t tmp2,tmp,z;
GPIO_ResetBits(PLL_SPI_MOSI_GPIO_PORT, PLL_SPI_MOSI_PIN);
for (z=0;z<14;z++)
{GPIO_SetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CLK
for (tmp2=0;tmp2<0x7fff;tmp2++)
	{tmp&=0xffff;};
	GPIO_ResetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Clr PLL CLK
for (tmp2=0;tmp2<0x7fff;tmp2++)
	{tmp&=0xffff;};
};
GPIO_SetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN); //Set PLL CS   DLEN
for (tmp2=0;tmp2<0x7fff;tmp2++)
	{tmp&=0xffff;};
GPIO_SetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
	for (tmp2=0;tmp2<0x7fff;tmp2++)
		{tmp&=0xffff;};
GPIO_ResetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
for (tmp2=0;tmp2<0x7fff;tmp2++)
	{tmp&=0xffff;};
for (z=0;z<16;z++)
{ //Set data
	//Clock pulse
	GPIO_WriteBit(PLL_SPI_MOSI_GPIO_PORT, PLL_SPI_MOSI_PIN, code&0x8000);
	GPIO_SetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
		for (tmp2=0;tmp2<0x7fff;tmp2++)
			{tmp&=0xffff;};
	GPIO_ResetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
	for (tmp2=0;tmp2<0x7fff;tmp2++)
		{tmp&=0xffff;};
code=code<<1;
}
for (tmp2=0;tmp2<0x7fff;tmp2++)
	{tmp&=0xffff;};
GPIO_ResetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN);
}

void PLLSoftSPI2(uint16_t code)
{uint16_t tmp2,tmp,z;
GPIO_ResetBits(PLL_SPI_MOSI_GPIO_PORT, PLL_SPI_MOSI_PIN);
GPIO_SetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN); //Set PLL CS   DLEN
for (tmp2=0;tmp2<0x7fff;tmp2++)
	{tmp&=0xffff;};
GPIO_SetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
	for (tmp2=0;tmp2<0x7fff;tmp2++)
		{tmp&=0xffff;};
GPIO_ResetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
for (tmp2=0;tmp2<0x7fff;tmp2++)
	{tmp&=0xffff;};
for (z=0;z<16;z++)
{ //Set data
	//Clock pulse
	GPIO_WriteBit(PLL_SPI_MOSI_GPIO_PORT, PLL_SPI_MOSI_PIN, code&0x8000);
	GPIO_SetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
		for (tmp2=0;tmp2<0x7fff;tmp2++)
			{tmp&=0xffff;};
	GPIO_ResetBits(PLL_SPI_SCK_GPIO_PORT, PLL_SPI_SCK_PIN); //Set PLL CS
	for (tmp2=0;tmp2<0x7fff;tmp2++)
		{tmp&=0xffff;};
code=code<<1;
}
GPIO_ResetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN);
}


void PLLSendFreq(uint16_t pll_div)
{
uint16_t tmp,tmp2;
tmp=pll_div&0xffff;
tmp=(tmp>272)? tmp:272;
while(SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_BSY));
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,0x28);//IN1 word
while(SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_BSY));
Delay(1);
GPIO_SetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN); //Set PLL CS
Delay(1);
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,(tmp&0xff));//LSB of frequency word
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,((uint8_t *)&tmp)[1]);//MSB of frequency word
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,0x12); //FM mode, prediv/2 100 kHz ref frequency 4.5M XTAL
while(SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_BSY)); //Wait till the end of transmission
Delay(1);
GPIO_ResetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN);
}

void PLLSendCtrlWord(uint32_t ctrl_word)
{uint16_t tmp,tmp2;
while(SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_BSY));
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,0x29);//IN2 word
while(SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_BSY));
Delay(1);
GPIO_SetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN); //Set PLL CS
Delay(1);
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,((uint8_t *)&ctrl_word)[0]);//
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,((uint8_t *)&ctrl_word)[1]);//DO=unlock, dead zone DZD
while(!SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_TXE));
SPI_I2S_SendData(PLL_SPI,((uint8_t *)&ctrl_word)[2]);
while(SPI_I2S_GetFlagStatus(PLL_SPI, SPI_I2S_FLAG_BSY)); //Wait till the end of transmission
Delay(1);
GPIO_ResetBits(PLL_SPI_CS_GPIO_PORT, PLL_SPI_CS_PIN);
}
