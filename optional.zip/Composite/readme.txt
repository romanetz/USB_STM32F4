Example description
===================
This Demo provides a description of how to use the USB-FS-Device on the STM32F4 devices.
The example combines the Mass Storage (MSC) and HID Device examples into a composite device.

Extract this zip and add to your USB_Device_Examples folder.
Add the new hid_msc class (Lib-hid_msc.zip) to your Libraries\STM32_USB_Device_Library\Class folder.